#    Copyright 2023 Haotian Liu
#
#    Licensed under the Apache License, Version 2.0 (the "License");
#    you may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.


from typing import List, Optional, Tuple, Union

import torch
import torch.nn as nn
from torch.nn import CrossEntropyLoss
import torchvision
from transformers import AutoConfig, AutoModelForCausalLM, \
                         LlamaConfig, LlamaModel, LlamaForCausalLM, AutoTokenizer

from transformers.modeling_outputs import CausalLMOutputWithPast

from ..llava_arch import LlavaMetaModel, LlavaMetaForCausalLM


class LlavaConfig(LlamaConfig):
    model_type = "llava"


class LlavaLlamaModel(LlavaMetaModel, LlamaModel):
    config_class = LlavaConfig

    def __init__(self, config: LlamaConfig):
        super(LlavaLlamaModel, self).__init__(config)


class LlavaLlamaForCausalLM(LlamaForCausalLM, LlavaMetaForCausalLM):
    config_class = LlavaConfig

    def __init__(self, config):
        super(LlamaForCausalLM, self).__init__(config)
        self.model = LlavaLlamaModel(config)

        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)
        
        # Initialize weights and apply final processing
        self.post_init()

    def get_model(self):
        return self.model

    def forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask: Optional[torch.Tensor] = None,
        past_key_values: Optional[List[torch.FloatTensor]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        images: Optional[torch.FloatTensor] = None,
        return_dict: Optional[bool] = None,
    ) -> Union[Tuple, CausalLMOutputWithPast]:
        output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
        output_hidden_states = (
            output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
        )
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        
        tokenizer=AutoTokenizer.from_pretrained('/root/szd/LLaVA1.5/ckpt/vicuna-7b-1.5-altered')
        



    
        boxindex=torch.where(input_ids==32000)
        aboxindex=torch.where(input_ids==32001)
        imagetoken=torch.where(input_ids==-200)
        endtoken=torch.where(input_ids==2)
     
        if len(aboxindex[0])!=len(endtoken[0]):
            print('abox index mismatch endtoken')
        gts=[]
        for i in range(0,len(aboxindex[0])):
            gts.append(tokenizer.decode(input_ids[aboxindex[0][i]][aboxindex[1][i]+1:endtoken[1][i]]))
        
        

        for i in range(0,len(gts)):
            gts[i]=[float(x) for x in gts[i][1:-1].replace(' ','').split(',')]
        
        # print(gts)

        # print('labels',labels)
        # print('aboxindex',aboxindex)
        labels[aboxindex]=-100    
        # print('after labels',labels)
        
        # if len(boxindex[0])!=len(imagetoken[0]):
        #     print('mis match imagetoken and boxindex')
        # print(boxindex)
        # print(imagetoken)
        
        for i in range(0,len(boxindex[0])):
            if boxindex[1][i]>imagetoken[1][boxindex[0][i]]:
                # print('change boxindex pos')
                boxindex[1][i]=boxindex[1][i]+575 
            else:
                print('boxindex < image index')
    
        # print(boxindex)
        input_ids, attention_mask, past_key_values, inputs_embeds, labels = self.prepare_inputs_labels_for_multimodal(input_ids, attention_mask, past_key_values, labels, images)

        # decoder outputs consists of (dec_features, layer_state, dec_hidden, dec_attn)
        outputs = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict
        )
        
        hidden_states = outputs[0]
        # print(hidden_states.shape)
        # print(input_ids)
        # if input_ids==32000:
        #     print('here')
        #     bboxout=self.model.bboxmlp(hidden_states)
        #     print(bboxout)
        box_feat=hidden_states[boxindex]
        # box_feat=relu(box_feat)
        bboxout=self.model.bboxmlp(box_feat)
        logits = self.lm_head(hidden_states)
        gts=torch.tensor(gts).to(bboxout.device)
        # print(bboxout.device) 
        # gts_altered=torch.tensor(gts).to(bboxout.device)
        # print(bboxout)
        # print(gts_altered)

        loss = None
        if labels is not None:
            alpha=2
            belta=3
            # Shift so that tokens < n predict n
            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()
            # Flatten the tokens
            loss_fct = CrossEntropyLoss()
            L1loss=nn.L1Loss()
            shift_logits = shift_logits.view(-1, self.config.vocab_size)
            shift_labels = shift_labels.view(-1)
            # Enable model/pipeline parallelism
            shift_labels = shift_labels.to(shift_logits.device)
            diou_loss=torchvision.ops.distance_box_iou_loss(bboxout,gts)
            diou_loss=torch.sum(diou_loss)/bboxout.shape[0]
            # giou_loss=torchvision.ops.generalized_box_iou_loss(bboxout,gts)
            # giou_loss=torch.sum(giou_loss)/bboxout.shape[0]
            l1lo=L1loss(bboxout,gts)
            # print('L1 loss',l1lo)
            # print('giou loss',diou_loss)
            loss = loss_fct(shift_logits, shift_labels)+belta*diou_loss+alpha*l1lo

        if not return_dict:
            output = (logits,) + outputs[1:]
            return (loss,) + output if loss is not None else output

        return CausalLMOutputWithPast(
            loss=loss,
            logits=logits,
            past_key_values=outputs.past_key_values,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )

    def prepare_inputs_for_generation(
        self, input_ids, past_key_values=None, attention_mask=None, inputs_embeds=None, **kwargs
    ):
        if past_key_values:
            input_ids = input_ids[:, -1:]

        # if `inputs_embeds` are passed, we only want to use them in the 1st generation step
        if inputs_embeds is not None and past_key_values is None:
            model_inputs = {"inputs_embeds": inputs_embeds}
        else:
            model_inputs = {"input_ids": input_ids}

        model_inputs.update(
            {
                "past_key_values": past_key_values,
                "use_cache": kwargs.get("use_cache"),
                "attention_mask": attention_mask,
                "images": kwargs.get("images", None),
            }
        )
        return model_inputs

AutoConfig.register("llava", LlavaConfig)
AutoModelForCausalLM.register(LlavaConfig, LlavaLlamaForCausalLM)
